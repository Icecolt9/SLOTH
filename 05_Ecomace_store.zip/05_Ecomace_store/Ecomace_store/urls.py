from django.contrib import admin
from django.urls import path, include
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    path('admin/', admin.site.urls),
    path("api/token/", TokenObtainPairView.as_view(), name="get_token"),#generates tokes
    path("api/token/refresh/", TokenRefreshView.as_view(), name="refresh"),#refreshes a token
    path('', include('api.urls')),
]
