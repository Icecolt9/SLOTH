from rest_framework import viewsets, permissions, status, decorators
from rest_framework.response import Response
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import check_password
from .models import Order, Product, User
from .permissions import IsOwnerOrReadOnly, StoreWriteCustomerReadOnly, IsCustomer
from rest_framework.exceptions import PermissionDenied
from .serializers import (
    UserSerializer,
    CreateUserSerializer,
    ChangePasswordSerializer,
    ProductSerializer,
    OrderSerializer,
    OrderCreateSerializer,
)


User = get_user_model()

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.prefetch_related('items__product')
    serializer_class = OrderSerializer
    permission_classes = [IsCustomer,IsOwnerOrReadOnly]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

    def get_serializer_class(self):
        if self.action == 'create' or self.action == 'update':
            return OrderCreateSerializer
        return super().get_serializer_class()

    def get_queryset(self):
        qs = super().get_queryset()
        qs = qs.filter(user=self.request.user)
        return qs

class ProductViewSet(viewsets.ModelViewSet):
    serializer_class = ProductSerializer
    permission_classes = [StoreWriteCustomerReadOnly]

    def get_queryset(self):
        user = self.request.user

        if user.is_authenticated and user.type == "Store" :
            return Product.objects.filter(store=user)

        return Product.objects.all()
        
    def perform_create(self, serializer):
        user = self.request.user
        if not (user and getattr(user, "is_authenticated", False) and getattr(user, "type", "").lower() == "store"):
            raise PermissionDenied(detail="Only users of type 'Store' may create products.")
        serializer.save(store=self.request.user)

    @decorators.action(detail=False, methods=["get"], url_path="store/(?P<store_id>[^/.]+)")
    def products_by_store(self, request, store_id=None):
        if request.user.type != "Customer":
            return Response(
                {"detail": "Only customers can view store products."},
                status=403
            )

        try:
            store = User.objects.get(id=store_id, type="Store")
        except User.DoesNotExist:
            return Response({"detail": "Store not found."}, status=404)

        products = Product.objects.filter(store=store)

        serializer = ProductSerializer(products, many=True)
        return Response(serializer.data)

class UserViewSet(viewsets.ModelViewSet):

    queryset = User.objects.all().order_by("id")

    http_method_names = ["get", "post", "put", "patch", "head", "options"]

    def get_serializer_class(self):
        if self.action == "create":
            return CreateUserSerializer

        if self.action == "change_password":
            return ChangePasswordSerializer

        return UserSerializer

    def get_permissions(self):
        if self.action == "create":
            return [permissions.AllowAny()]

        if self.action == "change_password":
            return [permissions.IsAuthenticated()]
            
        if self.action == "stores" :
            return [permissions.IsAuthenticated()]

        return [permissions.IsAuthenticated()]
        
    def get_queryset(self):
        qs = super().get_queryset()
        qs = qs.filter(pk=self.request.user.id)
        return qs

    def update(self, request, *args, **kwargs):
        if int(kwargs["pk"]) != request.user.id:
            return Response(
                {"detail": "You cannot update another user's profile."},
                status=status.HTTP_403_FORBIDDEN,
            )

        if "password" in request.data:
            return Response(
                {"detail": "Password cannot be updated here. Use /change_password/"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return super().update(request, *args, **kwargs)

    def partial_update(self, request, *args, **kwargs):
        if int(kwargs["pk"]) != request.user.id:
            return Response(
                {"detail": "You cannot update another user's profile."},
                status=status.HTTP_403_FORBIDDEN,
            )

        if "password" in request.data:
            return Response(
                {"detail": "Password cannot be updated here. Use /change_password/"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return super().partial_update(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        return Response(
            {"detail": "Deleting users is not allowed."},
            status=status.HTTP_403_FORBIDDEN,
        )

    @decorators.action(detail=False, methods=["post"], url_path="change_password")
    def change_password(self, request):
        serializer = ChangePasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        user = request.user

        if not user.check_password(serializer.validated_data["old_password"]):
            return Response(
                {"detail": "Old password is incorrect."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        user.set_password(serializer.validated_data["new_password"])
        user.save()

        return Response({"detail": "Password changed successfully."})
        
    @decorators.action(detail=False, methods=["get"], url_path="login")
    def login(self, request):

        user = request.user

        return Response(user)
        
    # ----------------------------
    #   CUSTOMER — VIEW ALL STORES
    # ----------------------------
    @decorators.action(detail=False, methods=["get"], url_path="stores")
    def stores(self, request):
        """
        GET /users/stores/
        Returns all users whose type == 'Store'
        Only allowed for authenticated CUSTOMER users.
        """
        if request.user.type != "Customer":
            return Response({"detail": "Only customers can view stores."}, status=403)

        stores = User.objects.filter(type="Store")
        serializer = UserSerializer(stores, many=True)
        return Response(serializer.data)
        
  

