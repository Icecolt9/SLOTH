from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register("users", views.UserViewSet, basename="users")
router.register("products", views.ProductViewSet, basename="products")
router.register("orders", views.OrderViewSet, basename="orders")

urlpatterns = [
    path("", include(router.urls)),
]
