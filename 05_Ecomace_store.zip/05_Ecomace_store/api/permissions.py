from rest_framework import permissions


class IsSotoreOwnerOrReadOnly(permissions.BasePermission):
    """
    Custom permission to only allow user type of store.
    """

    def has_object_permission(self, request, view, obj):
        # Read permissions are allowed to any request,
        # so we'll always allow GET, HEAD or OPTIONS requests.
                # Write permissions are only allowed to the owner and if owner is a Store.

        if request.method in permissions.SAFE_METHODS:
            return True
        
        return request.user.type == "Store" and obj.owner == request.user
    
class IsOwnerOrReadOnly(permissions.BasePermission):
    """
    Custom permission to only allow owners of an object to edit it.
    """

    def has_object_permission(self, request, view, obj):
        # Read permissions are allowed to any request,
        # so we'll always allow GET, HEAD or OPTIONS requests.
        if request.method in permissions.SAFE_METHODS:
            return True

        # Write permissions are only allowed to the owner of the snippet.
        return obj.user == request.user

class StoreWriteCustomerReadOnly(permissions.BasePermission):
    """
    Allow safe methods to everyone.
    For write methods require an authenticated user whose type is 'store' (case-insensitive).
    """

    def _is_store_user(self, user):
        return bool(user and getattr(user, "is_authenticated", False) and getattr(user, "type", "").lower() == "store")

    def has_permission(self, request, view):
        if request.method in permissions.SAFE_METHODS:
            return True

        return self._is_store_user(request.user)

    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True

        return self._is_store_user(request.user)
    
class IsCustomer(permissions.BasePermission):
    """
    Allow safe methods to everyone.
    For write methods require an authenticated user whose type is 'customer' (case-insensitive).
    """

    def _is_customer_user(self, user):
        return bool(user and getattr(user, "is_authenticated", False) and getattr(user, "type", "").lower() == "customer")

    def has_permission(self, request, view):
        return self._is_customer_user(request.user)

    def has_object_permission(self, request, view, obj):
        return self._is_customer_user(request.user)