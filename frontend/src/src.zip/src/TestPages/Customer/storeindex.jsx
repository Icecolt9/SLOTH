import './LandingPage.css'
import {FaSearch} from "react-icons/fa"

function Storeindex () {

    return (
        <div className="grid">
            <h1>Customer landing page</h1>
            <nav className="topbar">
                <span className="logo">
                    <h1>SLOTH</h1>
                    <p>one stop online mall</p>
                </span>

                <FaSearch />
            </nav>
            <main>

                <div>
                    <img src="" alt="" />
                    <p></p>
                    <span></span>
                    <span></span>
                </div>


            </main>
            <nav>

            </nav>
        </div>
    );

}

export default Storeindex;