import { useState } from 'react';
import './css/Storeindex.css'
import {FaBars, FaBell, FaChevronDown} from 'react-icons/fa'
import {MdClose} from 'react-icons/md'

function Storeindex() {

    const [close, setclose] = useState(true);
    const [openbtn, setopenbtn] = useState("none");

    const togglesidebar = () => {
        setclose(!close);
        if(close) 
        {
            setopenbtn("none");
        }
    }

    const isOn = (name) =>{
        return name === openbtn ;
    }

    return (
        <div className='bodycontainer'>
            <nav id='topbar'>
                <button className='toggle-btn' onClick={togglesidebar}>
                    { close ? <FaBars /> : <MdClose/> }
                </button>
                
                <div>
                    <h1>Sloth</h1>
                </div>

                <FaBell />
            </nav>
            <aside id='sidebar' className={ close ? "closed" : "open" }>
                <ul>
                    <li className="logo">
                        <span className="logo-text">Sloth</span>
                        <button className='toggle-btn' onClick={togglesidebar}>
                            <FaChevronDown />
                        </button>
                    </li>
                    <li>
                        <button className={"dropdown-btn "+( isOn("one") ? "rotate" : "") } onClick={ () => setopenbtn( openbtn == "one" ? "none" : "one")} > 
                            <FaBell />
                            <span>
                                mahlomola 
                                <br /> 
                                mahlomola@gmail.com 
                            </span>
                            <FaChevronDown />
                        </button>
                        <ul className={"sub-menu "+( isOn("one")? "show" : "") }>
                            <div>
                                <li onClick={togglesidebar}><a href="#">Settings</a></li>
                                <li onClick={togglesidebar}><a href="#">Profile</a></li>
                            </div>
                        </ul>
                    </li>
                    <li>
                        <button className={"dropdown-btn "+( isOn("two") ? "rotate" : "") } onClick={() => setopenbtn( openbtn == "two" ? "none" : "two")} >
                            <FaBell />
                            <span>
                            M 9000
                            </span>
                            <FaChevronDown />
                        </button>
                        <ul className={"sub-menu "+( isOn("two") ? "show" : "") }>
                            <div>
                                <li onClick={togglesidebar}><a href="#">Credit history</a></li>
                                <li onClick={togglesidebar}><a href="#">Credit history</a></li>
                                <li onClick={togglesidebar}><a href="#">Credit history</a></li>
                            </div>
                        </ul>
                    </li>
                    <li>
                        <button className={"dropdown-btn "+( isOn("three") ? "rotate" : "") } onClick={() => setopenbtn( openbtn == "three" ? "none" : "three") } >
                            <FaBell />
                            <span>
                            Analtics
                            </span>
                            <FaChevronDown />
                        </button>
                        <ul className={"sub-menu "+( isOn("three") ? "show" : "") }>
                            <div>
                                <li onClick={togglesidebar}><a href="#">Credit history</a></li>
                                <li onClick={togglesidebar}><a href="#">Credit history</a></li>
                                <li onClick={togglesidebar}><a href="#">Credit history</a></li>
                            </div>
                        </ul>
                    </li>
                    <li>
                        <a href="#" onClick={togglesidebar} >
                            <FaBell />
                            <span>Lice Chat</span>
                        </a>
                    </li>
                    <li>
                        <button className={"dropdown-btn "+( isOn("four") ? "rotate" : "") } onClick={() => setopenbtn( openbtn == "four" ? "none" : "four") } >
                            <FaBell />
                            <span>
                                help
                            </span>
                            <FaChevronDown />
                        </button>
                        <ul className={"sub-menu "+( isOn("four") ? "show" : "") }>
                            <div>
                                <li onClick={togglesidebar}><a href="#">Credit history</a></li>
                                <li onClick={togglesidebar}><a href="#">Credit history</a></li>
                                <li onClick={togglesidebar}><a href="#">Credit history</a></li>
                            </div>
                        </ul>
                    </li>
                </ul>
            </aside>
            <div id="overlay" onClick={togglesidebar} className={ close ? "closed" : "open" } > </div>
            <main id='main'>
                <h1>
                    WELCOME TO LESOTHO'S BEST ONLINE MALL
                </h1>
            </main>
        </div>
    );
}

export default Storeindex;