import axios from "axios";

const api = axios.create({
  baseURL: "http://127.0.0.1:8000",
});

// Add access token to every request
api.interceptors.request.use(async (config) => {
  const user = JSON.parse(localStorage.getItem("user"));

  if (user?.access) {
    config.headers.Authorization = `Bearer ${user.access}`;
  }

  return config;
});

// Auto refresh token on 401
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const originalRequest = error.config;

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      const user = JSON.parse(localStorage.getItem("user"));
      if (!user?.refresh) return Promise.reject(error);

      try {
        const refreshRes = await api.post("/api/token/refresh/", {
          refresh: user.refresh,
        });

        user.access = refreshRes.data.access;
        localStorage.setItem("user", JSON.stringify(user));

        originalRequest.headers.Authorization = `Bearer ${user.access}`;
        return api(originalRequest);
      } catch (refreshError) {
        localStorage.removeItem("user");
        window.location.href = "/login";
      }
    }

    return Promise.reject(error);
  }
);

export default api;