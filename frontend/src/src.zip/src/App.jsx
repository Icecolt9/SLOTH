import { Routes, Route } from "react-router-dom";
import Landing from "./pages/landing/Landing";
import Login from "./pages/login/Login";
import Signup from "./pages/signup/Signup";
import Storeindex from "./TestPages/Store/Storeindex";
import Customerindex from "./TestPages/Customer/Customerindex";

// dashboards
import CustomerDashboard from "./pages/loggedIn/customer/CustomerDashboard";
import StoreDashboard from "./pages/loggedIn/store/StoreDashboard";

import ProtectedRoute from "./components/ProtectedRoute";

function App() {
  return (
    <>
      <Routes>
        {/* Public Pages */}
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/test" element={<Storeindex />} />
        <Route path="/testcustomer" element={<Customerindex />} />
        {/* Customer Protected Route */}
        <Route
          path="/customer"
          element={
            <ProtectedRoute allowedRole="Customer">
              <CustomerDashboard />
            </ProtectedRoute>
          }
        />

        {/* Store Protected Route */}
        <Route
          path="/store"
          element={
            <ProtectedRoute allowedRole="Store">
              <StoreDashboard />
            </ProtectedRoute>
          }
        />
      </Routes>
    </>
  );
}

export default App;