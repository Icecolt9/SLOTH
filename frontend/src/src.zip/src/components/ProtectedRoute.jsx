import { Navigate } from "react-router-dom";

export default function ProtectedRoute({ children, allowedRole }) {
  const user = JSON.parse(localStorage.getItem("user")); 
  // user = { token: "...", role: "customer" or "store" }
  console.log("Logged in user is :", user );
  if (!user)
  {
    console.log("user not found navigating to the login page ");
    return <Navigate to="/login" />;
  }

  console.log("allowed role is :", allowedRole );
  console.log("user role is :", user.user.type);

  if (allowedRole && user.user.type !== allowedRole)
  {
    console.log("user role not determined navigating to the landing page ");
    return <Navigate to="/" />; // redirect if wrong role
  }

  return children;
}