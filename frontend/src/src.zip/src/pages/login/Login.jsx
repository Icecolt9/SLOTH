import React, { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import './login.css'

export default function Login() {
  const navigate = useNavigate();

  const [credentials, setCredentials] = useState({
    email: "",
    password: "",
  });

  const [error, setError] = useState("");

  const handleChange = (e) => {
    setCredentials({
      ...credentials,
      [e.target.name]: e.target.value,
    });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");

    try {

      const response = await axios.post(
        "http://localhost:8000/api/token/",
        credentials
      );
      
      console.log("credentials: ", credentials);
      console.log(response)

      localStorage.setItem("access", response.data.access);
      localStorage.setItem("refresh", response.data.refresh);

      console.log("Logged in:", response.data);
	
      const userDetails = await axios.get("http://localhost:8000/users/", {
        headers: {
          Authorization: `Bearer ${response.data.access}`,
        },
      });

	
     const userData = {
          access : response.data.access,
          refresh : response.data.refresh,
          user : userDetails.data[0]
      }

      console.log("User:", userData );
  
      localStorage.setItem("user",JSON.stringify(userData))

      if(userDetails.data[0].type == "Customer")
      {
      	 navigate("/customer");
      }
      else
      {
         navigate("/store");
      }
      

    } catch (err) {
      console.error(err);
      setError("Invalid email or password.");
    }
  };

    return (
      <div className="login-wrapper">
        <h1>Login</h1>

        {error && <p style={{ color: "red" }}>{error}</p>}

        <form className="login-form" onSubmit={handleLogin}>

          <label htmlFor="email">Email:</label>
          <input type="email" id="email" name="email" placeholder="Enter email" value={credentials.email} onChange={handleChange} required />

          <label htmlFor="password">Password:</label>
          <input type="password" id="password" name="password" placeholder="Enter password" value={credentials.password} onChange={handleChange} required />

          <div className="remember-forgot">
            <label > <input type="checkbox" /> Remember me </label> <a href="#"> Forgot password? </a>
          </div>

          <button type="submit" className="btn">Login</button>

          <div className="register-link"> <p>Don't have an accout? <a href="/signup">Register</a></p>  </div>

        </form>

        <p className="login-back">
          Back to <Link to="/">Home</Link>
        </p>
      </div>
  );
}