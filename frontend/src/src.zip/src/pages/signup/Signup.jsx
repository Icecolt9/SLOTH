import React, { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import './signup.css'

export default function Signup() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    type: "", 
  });

  const [error, setError] = useState("");

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSignin = async (e) => {
    e.preventDefault();
    setError("");

    try {
      // Send signup request EXACTLY as backend expects
      const response = await axios.post("http://localhost:8000/users/", formData);

      console.log("User created:", response.data);

      // go to login page
      navigate("/login");

    } catch (err) {
      console.error(err);
      setError("Signup failed. Check your details.");
    }
  };

    return (
      <div className="login-wrapper">
        <h1>Create Account</h1>

        {error && <p style={{ color: "red" }}>{error}</p>}

        <form className="login-form" onSubmit={handleSignin}>

          <label htmlFor="username">Username:</label>
          <input type="text" id="username" name="username" placeholder="Enter username" value={formData.username} onChange={handleChange} required />


          <label htmlFor="email">Email:</label>
          <input type="email" id="email" name="email" placeholder="Enter email" value={formData.email} onChange={handleChange} required />

          <label htmlFor="password">Password:</label>
          <input type="password" id="password" name="password" placeholder="Enter password" value={formData.password} onChange={handleChange} required />

          <label htmlFor="accountType">Account Type:</label>
          <select
            id="accountType"
            name="type"
            value={formData.type}
            onChange={handleChange}
          >
            <option value="customer">Customer</option>
            <option value="Store">Store</option>
            <option value="Rider" disabled>Rider</option>
          </select>

          <button type="submit" className="btn">Signup</button>

          <div className="register-link"> <p>Already have an account? <a href="/login">Login</a></p>  </div>

        </form>

        <p className="login-back">
          Back to <Link to="/">Home</Link>
        </p>
      </div>
  );
}