import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./landing.css"; 

const IndexPage = () => {
  const [showSignupOptions, setShowSignupOptions] = useState(false);

  return (
    <div className="index-wrapper">
      {/* Navbar */}
      <nav className="index-navbar">
        <div className="index-nav-links">
          <Link to="#">About</Link>
          <Link to="#">Contact</Link>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="index-hero">
        <h1 className="index-title">SLOTH</h1>
        <p className="index-tagline">Shop at your own pace</p>

        <div className="index-buttons">
          <Link to="/login" className="index-nav-link">
            Login
          </Link>

          <Link to="/signup" className="index-nav-link">
            Create account
          </Link>

        </div>
      </main>
    </div>
  );
};

export default IndexPage;
