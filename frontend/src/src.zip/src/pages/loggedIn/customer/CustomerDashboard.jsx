import React, { useState, useEffect } from 'react';
import axios from "axios";
import { Link, useNavigate, NavLink } from "react-router-dom";
import { FaBars, FaTimes, FaTshirt, FaPalette, FaAppleAlt, FaShoppingBag, FaHome, FaHeadphones } from "react-icons/fa";
import './customerDashboard.css';

export default function StoreDashboard() {

  const navigate = useNavigate();
  const [nav, setNav] = useState(false);
  const [stores, setStores] = useState([]);      
  const user = JSON.parse(localStorage.getItem("user"));

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/");
  };

  const openNavbar = () => setNav(true);
  const closeNavbar = () => setNav(false);

  useEffect(() => {
    const fetchStores = async () => {
      try {
        if (user) {
          const response = await axios.get("http://localhost:8000/users/stores/", {
            headers: {
              Authorization: `Bearer ${user.access}`,
            },
          });

          console.log("Stores found:", response.data);
          setStores(response.data);  
        }
      } catch (err) {
        console.error("Error loading stores:", err);
      }
    };

    fetchStores();
  }, []); // Runs once at load

  const [menuOpen, setMenuOpen] = useState(false);

  const [searchQuery, setSearchQuery] = useState("");
  
  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
    // You can later add search filtering logic here
  };

  return (
    <>
    <header className="navbar">
      {/* LEFT: BRAND */}
      <div className="nav-left">
        <div className="brand">
          <div className="brand-title">SLOTH</div>
          <div className="brand-sub">shop at your own pace</div>
        </div>
      </div>

      {/* MOBILE MENU ICON */}
      <div className="mobile-menu-icon" onClick={() => setMenuOpen(!menuOpen)}>
        {menuOpen ? <FaTimes size={26} /> : <FaBars size={26} />}
      </div>

      {/* RIGHT: LINKS */}
      <nav className={`nav-right ${menuOpen ? "open" : ""}`}>
        <NavLink to="/home" className="nav-link" end onClick={() => setMenuOpen(false)}>
          <FaHome /> Home
        </NavLink>

        <NavLink to="/clothing" className="nav-link" onClick={() => setMenuOpen(false)}>
          <FaTshirt /> Clothing
        </NavLink>

        <NavLink to="/cosmetics" className="nav-link" onClick={() => setMenuOpen(false)}>
          <FaPalette /> Cosmetics
        </NavLink>

        <NavLink to="/food" className="nav-link" onClick={() => setMenuOpen(false)}>
          <FaAppleAlt /> Food
        </NavLink>

        <NavLink to="/accessories" className="nav-link" onClick={() => setMenuOpen(false)}>
          <FaShoppingBag /> Accessories
        </NavLink>

        <NavLink to="/technology" className="nav-link" onClick={() => setMenuOpen(false)}>
          <FaHeadphones /> Technology
        </NavLink>
      </nav>
    </header>
    <div className="home">
      <h1>Shop At Your Own Pace</h1>
      <p>
        Welcome to Sloth, where you can browse and shop for your favorite items
        without any rush. Explore our categories and find what you need.
      </p>

      {/* Search bar */}
      <input
        type="text"
        className="search-bar"
        placeholder="Search for products..."
        value={searchQuery}
        onChange={handleSearch}
      />

      <div className="button-group">
        <button className="outlined-btn">Explore Categories</button>
        <button className="outlined-btn">Browse Trending</button>
      </div>
      <section id="stores" className="pg">
  <div className="container">
    <h2 className="stores-title">Available Stores</h2>

    {stores.length === 0 ? (
      <p className="no-stores">No stores available.</p>
    ) : (
      <div className="stores-grid">
        {stores.map((store) => (
          <div key={store.id} className="store-card">
            <div className="store-header">
              <FaShoppingBag className="store-icon" />
              <h3 className="store-name">{store.username}</h3>
            </div>

            <p className="store-email">
              <strong>Contact:</strong> {store.email}
            </p>

            <Link
              to={`/customer/store/${store.id}`}
              className="view-btn"
            >
              View Products
            </Link>
          </div>
        ))}
      </div>
    )}
  </div>
</section>
    </div>
    </>
  );
}